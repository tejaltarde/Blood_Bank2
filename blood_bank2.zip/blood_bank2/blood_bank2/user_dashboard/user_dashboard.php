<?php
	include('user_header.php');
?>

		<div class="main ">
			<!-- MAIN CONTENT -->
			<div class="main-content bg-secondary">
				<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<center>
							<h3 class="panel-title">LIFE BANK</h3>
							<p class="panel-subtitle">BY VF_Internship Team No 500</p>
							</center>
						</div>

<!-- 						
						<div class="panel-body">
							
							<div class="row">
								
								<style>
									.fa-user{
										font-size:30px;
										color:white;
									}
								</style>
								<div class="col-md-3">
									<div class="metric bg-info">
									<span class="icon fa fa-user"></span>
										<p>
											<span class="number">SUCHITRA</span>
											<span class="title">SAVARDEKAR</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric bg-info">
									<span class="icon fa fa-user"></span>
										<p>
											<span class="number">SAKSHI</span>
											<span class="title">SHIRSATHE</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric bg-info">
										<span class="icon fa fa-user"></span>
										<p>
											<span class="number">KAUSTUBH</span>
											<span class="title">UGALE</span>
										</p>
									</div>
								</div>
								
							</div>
							
						</div> -->
						
						<div class="panelfoot">
							<center>
							<img src="../upload/Screenshot 2022-08-30 193232.jpg" width="600px" alt="LIFE BANK">
							</center>
						</div>



					</div>
					<!-- END OVERVIEW -->
					
				
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2022 Developed by <a href="#" target="_blank">TEAM 500</a>.</p>
			</div>
		</footer>
	</div>

<?php
	include('user_footer.php');
?>