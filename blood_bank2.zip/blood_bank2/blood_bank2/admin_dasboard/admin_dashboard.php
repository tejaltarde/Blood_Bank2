<?php
	include('../header.php');
?>


		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<center>
							<h3 class="panel-title">LIFE BANK</h3>
							<p class="panel-subtitle">BY VF_Internship Team No 500</p>
							</center>
						</div>
						<div class="panel-body">
						<center>
							<img src="../assets/img/Screenshot 2022-08-30 193232.jpg" width="550px" alt="LIFE BANK">
						</center>
						</div>
					</div>
					<!-- END OVERVIEW -->
					
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
			<p class="copyright">&copy; 2022 Developed by <a href="#" target="_blank">TEAM 500</a>.</p>
			</div>
		</footer>
	</div>
	<?php
	include('../footer.php');
	?>