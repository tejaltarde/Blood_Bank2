<?php
	$connection = new mysqli('localhost', 'root', '', 'blood_bank');
?>